﻿using System;

namespace RangeTask
{
    class Range
    {
        public double From { get; set; }
        public double To { get; set; }

        public Range(double from, double to)
        {
            From = from;
            To = to;
        }

        public double GetLength()
        {
            return To - From;
        }

        public bool IsInside(double number)
        {
            return From <= number && number <= To;
        }

        public Range GetIntervalsIntersection(Range range1, Range range2)
        {
            if (range1.To <= range2.From || range1.From >= range2.To) // Должны пересекаться 2 конца диапазона
            {
                return null;
            }
            else
            {
                if (range1.From <= range2.From)
                {
                    From = range1.From;
                }
                else
                {
                    From = range2.From;
                }

                if (range1.To <= range2.To)
                {
                    this.To = range2.To;
                }
                else
                {
                    this.To = range2.To;
                }
            }

            return new Range(this.From, this.To);
        }

        public Range[] IntervalsCombining()
        {

        }
        /*
        Range[] rangeArray = new Range[2];
        rangeArray[0] = new Range(From, To);
        return rangeArray;*/
    }
}
